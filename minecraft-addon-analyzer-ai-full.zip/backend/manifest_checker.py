import json
import os
import re
import uuid
from json_validator import load_json_safe, save_json


REQUIRED_HEADER_FIELDS = ["name", "uuid", "version"]
REQUIRED_FIELDS = ["format_version", "header", "modules"]
VALID_MODULE_TYPES = [
    "data", "resources", "script", "world_template",
    "skin_pack", "javascript", "plugin"
]


def _is_valid_uuid(val: str) -> bool:
    try:
        uuid.UUID(str(val))
        return True
    except ValueError:
        return False


def _is_valid_version(val) -> bool:
    if isinstance(val, list) and len(val) == 3:
        return all(isinstance(v, int) and v >= 0 for v in val)
    return False


def check_manifest(manifest_path: str) -> dict:
    issues = []
    fixes = {}

    data = load_json_safe(manifest_path)
    if data is None:
        return {
            "issues": [{"severity": "error", "message": "manifest.json is missing or invalid JSON", "auto_fixable": False}],
            "fixes": {}
        }

    # Check top-level required fields
    for field in REQUIRED_FIELDS:
        if field not in data:
            issues.append({
                "severity": "error",
                "message": f"Missing required field: '{field}'",
                "fix_suggestion": f"Add '{field}' to manifest.json",
                "auto_fixable": True,
            })

    header = data.get("header", {})

    # Check header fields
    for field in REQUIRED_HEADER_FIELDS:
        if field not in header:
            issues.append({
                "severity": "error",
                "message": f"Missing header field: '{field}'",
                "fix_suggestion": f"Add 'header.{field}' to manifest.json",
                "auto_fixable": True,
            })

    # Validate UUID
    h_uuid = header.get("uuid", "")
    if h_uuid and not _is_valid_uuid(h_uuid):
        issues.append({
            "severity": "error",
            "message": f"Invalid header UUID: '{h_uuid}'",
            "fix_suggestion": "Generate a valid UUID v4",
            "auto_fixable": True,
        })
        fixes["header.uuid"] = str(uuid.uuid4())

    # Validate version
    h_version = header.get("version", None)
    if h_version is not None and not _is_valid_version(h_version):
        issues.append({
            "severity": "error",
            "message": f"Invalid version format: '{h_version}'. Expected [int, int, int]",
            "fix_suggestion": "Set version to [1, 0, 0]",
            "auto_fixable": True,
        })
        fixes["header.version"] = [1, 0, 0]

    # Check for missing name
    if not header.get("name", "").strip():
        issues.append({
            "severity": "warning",
            "message": "Addon has no name in header",
            "fix_suggestion": "Set header.name to a descriptive string",
            "auto_fixable": False,
        })

    # Check modules
    modules = data.get("modules", [])
    if not isinstance(modules, list) or len(modules) == 0:
        issues.append({
            "severity": "error",
            "message": "No modules defined",
            "fix_suggestion": "Add at least one module (type: 'data' or 'resources')",
            "auto_fixable": False,
        })
    else:
        seen_uuids = set()
        for i, mod in enumerate(modules):
            mod_uuid = mod.get("uuid", "")
            if mod_uuid:
                if mod_uuid == h_uuid:
                    issues.append({
                        "severity": "error",
                        "message": f"Module {i} has same UUID as header",
                        "fix_suggestion": "Generate unique UUID for module",
                        "auto_fixable": True,
                    })
                    fixes[f"modules[{i}].uuid"] = str(uuid.uuid4())
                if mod_uuid in seen_uuids:
                    issues.append({
                        "severity": "error",
                        "message": f"Duplicate UUID in module {i}: '{mod_uuid}'",
                        "fix_suggestion": "Generate unique UUID for module",
                        "auto_fixable": True,
                    })
                    fixes[f"modules[{i}].uuid"] = str(uuid.uuid4())
                seen_uuids.add(mod_uuid)
                if not _is_valid_uuid(mod_uuid):
                    issues.append({
                        "severity": "error",
                        "message": f"Module {i} has invalid UUID: '{mod_uuid}'",
                        "fix_suggestion": "Generate valid UUID",
                        "auto_fixable": True,
                    })

            mod_type = mod.get("type", "")
            if mod_type and mod_type not in VALID_MODULE_TYPES:
                issues.append({
                    "severity": "warning",
                    "message": f"Module {i} has unknown type: '{mod_type}'",
                    "fix_suggestion": f"Valid types: {', '.join(VALID_MODULE_TYPES)}",
                    "auto_fixable": False,
                })

            if not _is_valid_version(mod.get("version", None)):
                issues.append({
                    "severity": "error",
                    "message": f"Module {i} has invalid or missing version",
                    "fix_suggestion": "Set module version to [1, 0, 0]",
                    "auto_fixable": True,
                })
                fixes[f"modules[{i}].version"] = [1, 0, 0]

    # Check dependencies
    deps = data.get("dependencies", [])
    for i, dep in enumerate(deps):
        dep_uuid = dep.get("uuid", "")
        if dep_uuid and not _is_valid_uuid(dep_uuid):
            issues.append({
                "severity": "error",
                "message": f"Dependency {i} has invalid UUID: '{dep_uuid}'",
                "fix_suggestion": "Provide valid UUID for dependency",
                "auto_fixable": False,
            })

    return {"issues": issues, "fixes": fixes}


def auto_fix_manifest(manifest_path: str) -> bool:
    """Apply auto-fixes to manifest.json."""
    data = load_json_safe(manifest_path)
    if data is None:
        return False

    changed = False

    # Fix format_version
    if "format_version" not in data:
        data["format_version"] = 2
        changed = True

    # Fix header
    if "header" not in data:
        data["header"] = {}
        changed = True

    header = data["header"]

    if not header.get("uuid") or not _is_valid_uuid(header.get("uuid", "")):
        header["uuid"] = str(uuid.uuid4())
        changed = True

    if not _is_valid_version(header.get("version")):
        header["version"] = [1, 0, 0]
        changed = True

    if not header.get("name", "").strip():
        header["name"] = "My Addon"
        changed = True

    if not header.get("description", "").strip():
        header["description"] = "A Minecraft Bedrock Edition addon"
        changed = True

    # Fix modules
    if "modules" not in data or not data["modules"]:
        data["modules"] = [{
            "type": "data",
            "uuid": str(uuid.uuid4()),
            "version": [1, 0, 0]
        }]
        changed = True
    else:
        seen_uuids = {header.get("uuid")}
        for mod in data["modules"]:
            if not _is_valid_uuid(mod.get("uuid", "")):
                mod["uuid"] = str(uuid.uuid4())
                changed = True
            if mod["uuid"] in seen_uuids:
                mod["uuid"] = str(uuid.uuid4())
                changed = True
            seen_uuids.add(mod["uuid"])
            if not _is_valid_version(mod.get("version")):
                mod["version"] = [1, 0, 0]
                changed = True

    if changed:
        return save_json(manifest_path, data)
    return True
