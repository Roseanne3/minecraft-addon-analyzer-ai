import json
import re
import os


def validate_json_file(file_path: str) -> dict:
    """Validate a JSON file and return issues found."""
    issues = []
    fixed_content = None

    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            raw = f.read()
    except Exception as e:
        return {"issues": [{"severity": "error", "message": f"Cannot read file: {e}", "auto_fixable": False}], "fixed_content": None}

    if not raw.strip():
        return {"issues": [{"severity": "warning", "message": "File is empty", "auto_fixable": False}], "fixed_content": None}

    try:
        json.loads(raw)
    except json.JSONDecodeError as e:
        issues.append({
            "severity": "error",
            "message": f"Invalid JSON syntax: {e.msg} at line {e.lineno}, col {e.colno}",
            "fix_suggestion": "Auto-repair JSON structure",
            "auto_fixable": True,
        })
        fixed_content = _attempt_json_repair(raw)

    return {"issues": issues, "fixed_content": fixed_content}


def _attempt_json_repair(raw: str) -> str:
    """Attempt basic JSON repair."""
    try:
        # Remove trailing commas before ] or }
        fixed = re.sub(r",\s*([}\]])", r"\1", raw)
        # Remove single-line comments
        fixed = re.sub(r"//[^\n]*", "", fixed)
        # Remove block comments
        fixed = re.sub(r"/\*.*?\*/", "", fixed, flags=re.DOTALL)
        json.loads(fixed)
        return fixed
    except Exception:
        pass

    # Try to balance braces
    try:
        open_braces = raw.count("{") - raw.count("}")
        open_brackets = raw.count("[") - raw.count("]")
        fixed = raw.rstrip()
        if open_braces > 0:
            fixed += "}" * open_braces
        if open_brackets > 0:
            fixed += "]" * open_brackets
        json.loads(fixed)
        return fixed
    except Exception:
        pass

    return None


def load_json_safe(file_path: str):
    """Safely load JSON, returning None on failure."""
    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            return json.load(f)
    except Exception:
        return None


def save_json(file_path: str, data) -> bool:
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True
    except Exception:
        return False
