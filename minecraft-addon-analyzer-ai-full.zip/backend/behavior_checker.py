import os
import re
from json_validator import load_json_safe

IDENTIFIER_PATTERN = re.compile(r"^[a-z0-9_]+:[a-z0-9_/]+$")


def _check_identifier(identifier: str) -> bool:
    return bool(IDENTIFIER_PATTERN.match(str(identifier)))


def check_entity(file_path: str, rel_path: str) -> list:
    issues = []
    data = load_json_safe(file_path)
    if data is None:
        return issues

    bp = data.get("minecraft:entity", {})
    if not bp:
        issues.append({
            "severity": "error",
            "message": "Missing 'minecraft:entity' root key",
            "file_path": rel_path,
            "fix_suggestion": "Wrap entity data in 'minecraft:entity'",
            "auto_fixable": False,
        })
        return issues

    desc = bp.get("description", {})
    identifier = desc.get("identifier", "")
    if not identifier:
        issues.append({
            "severity": "error",
            "message": "Entity missing 'description.identifier'",
            "file_path": rel_path,
            "fix_suggestion": "Add 'description.identifier': 'namespace:entity_name'",
            "auto_fixable": False,
        })
    elif not _check_identifier(identifier):
        issues.append({
            "severity": "error",
            "message": f"Invalid entity identifier: '{identifier}'. Must be 'namespace:name'",
            "file_path": rel_path,
            "fix_suggestion": "Use lowercase letters, numbers, and underscores only",
            "auto_fixable": False,
        })

    components = bp.get("components", {})
    if not components:
        issues.append({
            "severity": "warning",
            "message": "Entity has no components defined",
            "file_path": rel_path,
            "fix_suggestion": "Add basic components like 'minecraft:physics' or 'minecraft:health'",
            "auto_fixable": False,
        })

    # Check for health component
    if "minecraft:health" not in components:
        issues.append({
            "severity": "info",
            "message": "Entity missing 'minecraft:health' component",
            "file_path": rel_path,
            "fix_suggestion": "Add 'minecraft:health': {'value': 20, 'max': 20}",
            "auto_fixable": True,
        })

    # Check events
    events = bp.get("events", {})
    component_groups = bp.get("component_groups", {})
    for event_name, event_data in events.items():
        if isinstance(event_data, dict):
            add = event_data.get("add", {}).get("component_groups", [])
            remove = event_data.get("remove", {}).get("component_groups", [])
            for cg in add + remove:
                if cg not in component_groups:
                    issues.append({
                        "severity": "error",
                        "message": f"Event '{event_name}' references undefined component group: '{cg}'",
                        "file_path": rel_path,
                        "fix_suggestion": f"Define component group '{cg}' or remove reference",
                        "auto_fixable": False,
                    })

    return issues


def check_item(file_path: str, rel_path: str) -> list:
    issues = []
    data = load_json_safe(file_path)
    if data is None:
        return issues

    item = data.get("minecraft:item", {})
    if not item:
        issues.append({
            "severity": "error",
            "message": "Missing 'minecraft:item' root key",
            "file_path": rel_path,
            "fix_suggestion": "Wrap item data in 'minecraft:item'",
            "auto_fixable": False,
        })
        return issues

    desc = item.get("description", {})
    identifier = desc.get("identifier", "")
    if not identifier:
        issues.append({
            "severity": "error",
            "message": "Item missing 'description.identifier'",
            "file_path": rel_path,
            "fix_suggestion": "Add 'description.identifier': 'namespace:item_name'",
            "auto_fixable": False,
        })
    elif not _check_identifier(identifier):
        issues.append({
            "severity": "error",
            "message": f"Invalid item identifier: '{identifier}'",
            "file_path": rel_path,
            "fix_suggestion": "Use 'namespace:item_name' format with lowercase",
            "auto_fixable": False,
        })

    return issues


def check_loot_table(file_path: str, rel_path: str) -> list:
    issues = []
    data = load_json_safe(file_path)
    if data is None:
        return issues

    pools = data.get("pools", [])
    if not pools:
        issues.append({
            "severity": "warning",
            "message": "Loot table has no pools",
            "file_path": rel_path,
            "fix_suggestion": "Add at least one pool with rolls and entries",
            "auto_fixable": False,
        })
    return issues


def check_behavior_pack(bp_path: str) -> list:
    all_issues = []
    if not os.path.isdir(bp_path):
        return all_issues

    for root, dirs, files in os.walk(bp_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, bp_path)
            path_lower = rel.lower()

            if "entities" in path_lower or "entity" in path_lower:
                all_issues.extend(check_entity(full, rel))
            elif "items" in path_lower or "item" in path_lower:
                all_issues.extend(check_item(full, rel))
            elif "loot_table" in path_lower or "loot_tables" in path_lower:
                all_issues.extend(check_loot_table(full, rel))

    return all_issues
