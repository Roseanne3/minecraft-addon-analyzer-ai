import zipfile
import os
import shutil


def extract_addon(file_path: str, extract_to: str) -> dict:
    """Extract uploaded addon (ZIP, MCADDON, MCPACK) to target directory."""
    result = {"success": False, "path": extract_to, "error": None, "file_count": 0}

    if not os.path.exists(file_path):
        result["error"] = f"File not found: {file_path}"
        return result

    os.makedirs(extract_to, exist_ok=True)

    try:
        # MCADDON, MCPACK, and ZIP are all ZIP-based formats
        if zipfile.is_zipfile(file_path):
            with zipfile.ZipFile(file_path, "r") as z:
                z.extractall(extract_to)
                result["file_count"] = len(z.namelist())
            result["success"] = True
        else:
            result["error"] = "File is not a valid ZIP/MCADDON/MCPACK archive"
    except zipfile.BadZipFile as e:
        result["error"] = f"Corrupt archive: {str(e)}"
    except Exception as e:
        result["error"] = f"Extraction failed: {str(e)}"

    return result


def scan_file_tree(base_path: str) -> list:
    """Recursively scan extracted addon and return file list with metadata."""
    files = []
    if not os.path.exists(base_path):
        return files

    for root, dirs, filenames in os.walk(base_path):
        # Skip hidden directories
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in filenames:
            if fname.startswith("."):
                continue
            full_path = os.path.join(root, fname)
            rel_path = os.path.relpath(full_path, base_path)
            ext = os.path.splitext(fname)[1].lower()
            size = os.path.getsize(full_path)
            files.append({
                "full_path": full_path,
                "relative_path": rel_path,
                "filename": fname,
                "extension": ext,
                "size": size,
                "type": _classify_file(ext, rel_path),
            })
    return files


def _classify_file(ext: str, path: str) -> str:
    path_lower = path.lower()
    if ext == ".json":
        if "manifest" in path_lower:
            return "manifest"
        elif "entity" in path_lower or "entities" in path_lower:
            return "entity"
        elif "item" in path_lower or "items" in path_lower:
            return "item"
        elif "loot" in path_lower:
            return "loot_table"
        elif "animation" in path_lower:
            return "animation"
        elif "model" in path_lower or "geo" in path_lower:
            return "model"
        elif "particle" in path_lower:
            return "particle"
        elif "biome" in path_lower:
            return "biome"
        return "json"
    elif ext in [".png", ".jpg", ".jpeg", ".tga"]:
        return "texture"
    elif ext in [".js", ".ts"]:
        return "script"
    elif ext in [".mcfunction", ".function"]:
        return "function"
    elif ext in [".ogg", ".wav", ".mp3", ".fsb"]:
        return "sound"
    elif ext in [".mcaddon", ".mcpack", ".zip"]:
        return "archive"
    return "other"
