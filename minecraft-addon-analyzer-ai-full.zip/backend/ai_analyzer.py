import os
from json_validator import load_json_safe


def analyze_with_ai(file_list: list, addon_path: str) -> list:
    """
    Rule-based AI analysis that provides developer-focused suggestions
    beyond basic validation — mimicking intelligent code review.
    """
    suggestions = []

    entity_files = [f for f in file_list if f["type"] == "entity"]
    script_files = [f for f in file_list if f["type"] == "script"]
    json_files = [f for f in file_list if f["extension"] == ".json"]
    texture_files = [f for f in file_list if f["type"] == "texture"]

    # Check for monolithic entity files
    for f in entity_files:
        data = load_json_safe(f["full_path"])
        if not data:
            continue
        entity = data.get("minecraft:entity", {})
        component_groups = entity.get("component_groups", {})
        components = entity.get("components", {})
        events = entity.get("events", {})

        if len(component_groups) > 15:
            suggestions.append({
                "severity": "info",
                "message": f"AI: Entity '{f['relative_path']}' has {len(component_groups)} component groups — consider splitting into sub-entities or using flags",
                "file_path": f["relative_path"],
                "fix_suggestion": "Refactor: move related component groups into separate entity variants or use spawn rules",
                "auto_fixable": False,
            })

        if len(events) > 20:
            suggestions.append({
                "severity": "info",
                "message": f"AI: Entity has {len(events)} events — high complexity may cause maintenance issues",
                "file_path": f["relative_path"],
                "fix_suggestion": "Consider splitting complex entities into smaller, focused entities",
                "auto_fixable": False,
            })

        # Check for AI goal conflicts
        goals = {k: v for k, v in components.items() if "behavior" in k.lower()}
        if len(goals) > 10:
            suggestions.append({
                "severity": "info",
                "message": f"AI: Entity has {len(goals)} behavior goals — may cause pathfinding conflicts",
                "file_path": f["relative_path"],
                "fix_suggestion": "Review goal priorities; ensure no conflicting movement behaviors",
                "auto_fixable": False,
            })

    # Check for script complexity
    for f in script_files:
        size_kb = f["size"] / 1024
        if size_kb > 50:
            suggestions.append({
                "severity": "info",
                "message": f"AI: Script file is {size_kb:.1f} KB — consider modularizing",
                "file_path": f["relative_path"],
                "fix_suggestion": "Split into multiple modules: entities.js, world.js, ui.js etc.",
                "auto_fixable": False,
            })
        try:
            with open(f["full_path"], "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
            if "system.registerComponent" in content and content.count("system.registerComponent") > 5:
                suggestions.append({
                    "severity": "info",
                    "message": f"AI: Many registerComponent calls in '{f['relative_path']}' — consider a registry pattern",
                    "file_path": f["relative_path"],
                    "fix_suggestion": "Create a component registry module to reduce repeated registration boilerplate",
                    "auto_fixable": False,
                })
        except Exception:
            pass

    # Check texture naming conventions
    bad_names = []
    for f in texture_files:
        name = os.path.splitext(f["filename"])[0]
        if " " in name or any(c.isupper() for c in name):
            bad_names.append(f["relative_path"])
    if bad_names:
        suggestions.append({
            "severity": "info",
            "message": f"AI: {len(bad_names)} texture(s) use uppercase or spaces in filenames — Bedrock is case-sensitive on some platforms",
            "file_path": bad_names[0],
            "fix_suggestion": "Rename textures to lowercase_with_underscores.png",
            "auto_fixable": False,
        })

    # General addon health summary
    total_json = len(json_files)
    if total_json > 100:
        suggestions.append({
            "severity": "info",
            "message": f"AI: Addon has {total_json} JSON files — large addons may load slowly on older devices",
            "file_path": "/",
            "fix_suggestion": "Audit for unused JSON definitions and remove or merge where possible",
            "auto_fixable": False,
        })

    return suggestions
