import os
import json
from json_validator import load_json_safe

VALID_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tga"}
MAX_TEXTURE_SIZE_MB = 2


def check_textures(rp_path: str) -> list:
    issues = []
    textures_dir = os.path.join(rp_path, "textures")
    if not os.path.isdir(textures_dir):
        issues.append({
            "severity": "warning",
            "message": "No 'textures' folder found in resource pack",
            "file_path": "textures/",
            "fix_suggestion": "Create a 'textures' folder and add PNG files",
            "auto_fixable": False,
        })
        return issues

    for root, dirs, files in os.walk(textures_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, rp_path)
            size_mb = os.path.getsize(full) / (1024 * 1024)
            if ext in VALID_IMAGE_EXTS:
                if size_mb > MAX_TEXTURE_SIZE_MB:
                    issues.append({
                        "severity": "warning",
                        "message": f"Large texture file ({size_mb:.1f} MB): {rel}",
                        "file_path": rel,
                        "fix_suggestion": "Optimize texture; target under 2 MB",
                        "auto_fixable": False,
                    })
    return issues


def check_animations(rp_path: str) -> list:
    issues = []
    anim_dir = os.path.join(rp_path, "animations")
    if not os.path.isdir(anim_dir):
        return issues

    for root, dirs, files in os.walk(anim_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, rp_path)
            data = load_json_safe(full)
            if data is None:
                continue

            anims = data.get("animations", {})
            for anim_id, anim_data in anims.items():
                if not isinstance(anim_data, dict):
                    issues.append({
                        "severity": "error",
                        "message": f"Animation '{anim_id}' is not an object",
                        "file_path": rel,
                        "fix_suggestion": "Animation must be a JSON object",
                        "auto_fixable": False,
                    })
                    continue
                if "animation_length" not in anim_data:
                    issues.append({
                        "severity": "warning",
                        "message": f"Animation '{anim_id}' missing 'animation_length'",
                        "file_path": rel,
                        "fix_suggestion": "Add 'animation_length' (in seconds) to animation",
                        "auto_fixable": False,
                    })
                bones = anim_data.get("bones", {})
                if len(bones) > 50:
                    issues.append({
                        "severity": "warning",
                        "message": f"Animation '{anim_id}' has {len(bones)} bones — may impact performance",
                        "file_path": rel,
                        "fix_suggestion": "Simplify animation or split into multiple files",
                        "auto_fixable": False,
                    })
    return issues


def check_models(rp_path: str) -> list:
    issues = []
    models_dir = os.path.join(rp_path, "models")
    if not os.path.isdir(models_dir):
        return issues

    for root, dirs, files in os.walk(models_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, rp_path)
            data = load_json_safe(full)
            if data is None:
                continue

            # Check geometry format
            geo = data.get("minecraft:geometry", [])
            if not geo:
                issues.append({
                    "severity": "warning",
                    "message": f"Model file has no 'minecraft:geometry' array: {rel}",
                    "file_path": rel,
                    "fix_suggestion": "Use format 'minecraft:geometry' with description and bones",
                    "auto_fixable": False,
                })
            else:
                for i, g in enumerate(geo):
                    if "description" not in g:
                        issues.append({
                            "severity": "error",
                            "message": f"Geometry {i} missing 'description' in {rel}",
                            "file_path": rel,
                            "fix_suggestion": "Add 'description' with 'identifier' field",
                            "auto_fixable": False,
                        })
    return issues


def check_animation_controllers(rp_path: str) -> list:
    issues = []
    ac_dir = os.path.join(rp_path, "animation_controllers")
    if not os.path.isdir(ac_dir):
        return issues

    for root, dirs, files in os.walk(ac_dir):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, rp_path)
            data = load_json_safe(full)
            if data is None:
                continue

            controllers = data.get("animation_controllers", {})
            for ctrl_id, ctrl in controllers.items():
                states = ctrl.get("states", {})
                if not states:
                    issues.append({
                        "severity": "error",
                        "message": f"Animation controller '{ctrl_id}' has no states",
                        "file_path": rel,
                        "fix_suggestion": "Add at least a 'default' state",
                        "auto_fixable": False,
                    })
                    continue
                if "default" not in states:
                    issues.append({
                        "severity": "warning",
                        "message": f"Animation controller '{ctrl_id}' has no 'default' state",
                        "file_path": rel,
                        "fix_suggestion": "Add a 'default' state as entry point",
                        "auto_fixable": False,
                    })
    return issues


def check_resource_pack(rp_path: str) -> list:
    if not os.path.isdir(rp_path):
        return []

    issues = []
    issues.extend(check_textures(rp_path))
    issues.extend(check_animations(rp_path))
    issues.extend(check_models(rp_path))
    issues.extend(check_animation_controllers(rp_path))
    return issues
