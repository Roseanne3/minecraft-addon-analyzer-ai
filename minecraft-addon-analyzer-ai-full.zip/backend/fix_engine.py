import os
import shutil
import zipfile
import json
import uuid
from manifest_checker import auto_fix_manifest
from json_validator import validate_json_file, save_json, load_json_safe


def apply_fixes(addon_path: str, fixed_output_dir: str, addon_id: int) -> dict:
    """
    Copy addon, apply all auto-fixable issues, and return a zip of the fixed addon.
    """
    result = {
        "success": False,
        "fixed_path": None,
        "fixes_applied": [],
        "error": None,
    }

    fixed_addon_path = os.path.join(fixed_output_dir, f"addon_{addon_id}_fixed")
    if os.path.exists(fixed_addon_path):
        shutil.rmtree(fixed_addon_path)
    shutil.copytree(addon_path, fixed_addon_path)

    fixes_applied = []

    # Fix 1: Repair broken JSON files
    for root, dirs, files in os.walk(fixed_addon_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            json_result = validate_json_file(full)
            if json_result["fixed_content"]:
                try:
                    with open(full, "w", encoding="utf-8") as f:
                        f.write(json_result["fixed_content"])
                    fixes_applied.append(f"Repaired JSON syntax: {os.path.relpath(full, fixed_addon_path)}")
                except Exception as e:
                    pass

    # Fix 2: Fix manifests
    for root, dirs, files in os.walk(fixed_addon_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if fname == "manifest.json":
                full = os.path.join(root, fname)
                rel = os.path.relpath(full, fixed_addon_path)
                if auto_fix_manifest(full):
                    fixes_applied.append(f"Fixed manifest: {rel}")

    # Fix 3: Create missing structure
    # Look for behavior_packs / resource_packs
    has_bp = any("behavior" in d.lower() for d in os.listdir(fixed_addon_path) if os.path.isdir(os.path.join(fixed_addon_path, d)))
    has_rp = any("resource" in d.lower() or "texture" in d.lower() for d in os.listdir(fixed_addon_path) if os.path.isdir(os.path.join(fixed_addon_path, d)))

    if not has_bp:
        bp_dir = os.path.join(fixed_addon_path, "behavior_packs", "my_behavior_pack")
        os.makedirs(bp_dir, exist_ok=True)
        fixes_applied.append("Created missing behavior_packs directory")

    if not has_rp:
        rp_dir = os.path.join(fixed_addon_path, "resource_packs", "my_resource_pack")
        os.makedirs(rp_dir, exist_ok=True)
        fixes_applied.append("Created missing resource_packs directory")

    # Fix 4: Add missing health component to entities
    for root, dirs, files in os.walk(fixed_addon_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if not fname.endswith(".json"):
                continue
            full = os.path.join(root, fname)
            rel_lower = os.path.relpath(full, fixed_addon_path).lower()
            if "entities" in rel_lower or "entity" in rel_lower:
                data = load_json_safe(full)
                if data and "minecraft:entity" in data:
                    components = data["minecraft:entity"].get("components", {})
                    if "minecraft:health" not in components:
                        components["minecraft:health"] = {"value": 20, "max": 20}
                        data["minecraft:entity"]["components"] = components
                        save_json(full, data)
                        fixes_applied.append(f"Added missing health component: {os.path.relpath(full, fixed_addon_path)}")

    # Fix 5: Fix module versions in manifests
    for root, dirs, files in os.walk(fixed_addon_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if fname != "manifest.json":
                continue
            full = os.path.join(root, fname)
            data = load_json_safe(full)
            if not data:
                continue
            changed = False
            for mod in data.get("modules", []):
                if not isinstance(mod.get("version"), list) or len(mod["version"]) != 3:
                    mod["version"] = [1, 0, 0]
                    changed = True
                if not mod.get("uuid"):
                    mod["uuid"] = str(uuid.uuid4())
                    changed = True
            if changed:
                save_json(full, data)

    # Package into ZIP
    zip_path = os.path.join(fixed_output_dir, f"fixed_addon_{addon_id}.zip")
    try:
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(fixed_addon_path):
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for fname in files:
                    full = os.path.join(root, fname)
                    arcname = os.path.relpath(full, fixed_addon_path)
                    zf.write(full, arcname)
        result["success"] = True
        result["fixed_path"] = zip_path
        result["fixes_applied"] = fixes_applied
    except Exception as e:
        result["error"] = f"Failed to create zip: {str(e)}"

    # Cleanup temp dir
    try:
        shutil.rmtree(fixed_addon_path)
    except Exception:
        pass

    return result
