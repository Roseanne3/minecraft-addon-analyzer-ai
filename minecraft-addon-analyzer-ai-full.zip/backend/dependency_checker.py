import os
import uuid
from json_validator import load_json_safe


def _is_valid_uuid(val: str) -> bool:
    try:
        uuid.UUID(str(val))
        return True
    except ValueError:
        return False


def check_dependencies(addon_path: str) -> list:
    """Check that all dependency UUIDs are consistent across packs."""
    issues = []
    all_manifests = []

    for root, dirs, files in os.walk(addon_path):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for fname in files:
            if fname == "manifest.json":
                full = os.path.join(root, fname)
                data = load_json_safe(full)
                if data:
                    rel = os.path.relpath(full, addon_path)
                    all_manifests.append({"path": rel, "data": data})

    # Collect all known pack UUIDs
    known_uuids = {}
    for m in all_manifests:
        h_uuid = m["data"].get("header", {}).get("uuid", "")
        if h_uuid:
            known_uuids[h_uuid] = m["path"]

    # Check each manifest's dependencies
    for m in all_manifests:
        deps = m["data"].get("dependencies", [])
        for i, dep in enumerate(deps):
            dep_uuid = dep.get("uuid", "")
            if not dep_uuid:
                issues.append({
                    "severity": "error",
                    "message": f"Dependency {i} in '{m['path']}' has no UUID",
                    "file_path": m["path"],
                    "fix_suggestion": "Add a valid UUID for the dependency",
                    "auto_fixable": False,
                })
            elif not _is_valid_uuid(dep_uuid):
                issues.append({
                    "severity": "error",
                    "message": f"Dependency {i} in '{m['path']}' has invalid UUID: '{dep_uuid}'",
                    "file_path": m["path"],
                    "fix_suggestion": "Use a valid UUID v4 format",
                    "auto_fixable": False,
                })
            elif dep_uuid not in known_uuids and len(known_uuids) > 1:
                issues.append({
                    "severity": "warning",
                    "message": f"Dependency UUID '{dep_uuid}' not found in any included pack manifests",
                    "file_path": m["path"],
                    "fix_suggestion": "Ensure the required pack is included, or update the UUID",
                    "auto_fixable": False,
                })

    # Check if BP declares dependency on RP and vice versa
    if len(all_manifests) >= 2:
        for m in all_manifests:
            module_types = [mod.get("type", "") for mod in m["data"].get("modules", [])]
            if "data" in module_types:
                # This is BP, check it has RP dependency
                dep_uuids = [d.get("uuid", "") for d in m["data"].get("dependencies", [])]
                # Find RP uuid
                for other in all_manifests:
                    other_types = [mod.get("type", "") for mod in other["data"].get("modules", [])]
                    if "resources" in other_types:
                        rp_uuid = other["data"].get("header", {}).get("uuid", "")
                        if rp_uuid and rp_uuid not in dep_uuids:
                            issues.append({
                                "severity": "info",
                                "message": f"Behavior pack '{m['path']}' does not declare resource pack as dependency",
                                "file_path": m["path"],
                                "fix_suggestion": f"Add resource pack UUID '{rp_uuid}' to behavior pack dependencies",
                                "auto_fixable": True,
                            })
    return issues
