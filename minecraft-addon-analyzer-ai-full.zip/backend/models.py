from sqlalchemy import Column, Integer, String, Float, DateTime, Text, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, default="anonymous")
    created_at = Column(DateTime, default=datetime.utcnow)
    addons = relationship("Addon", back_populates="user")


class Addon(Base):
    __tablename__ = "addons"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    filename = Column(String)
    original_path = Column(String)
    extracted_path = Column(String)
    upload_time = Column(DateTime, default=datetime.utcnow)
    score = Column(Float, default=0.0)
    status = Column(String, default="pending")  # pending, analyzing, done, error
    user = relationship("User", back_populates="addons")
    reports = relationship("Report", back_populates="addon")
    files = relationship("FileRecord", back_populates="addon")


class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True, index=True)
    addon_id = Column(Integer, ForeignKey("addons.id"))
    report_type = Column(String)  # manifest, json, behavior, resource, dependency, performance, ai
    severity = Column(String)  # error, warning, info
    message = Column(Text)
    file_path = Column(String, nullable=True)
    fix_suggestion = Column(Text, nullable=True)
    auto_fixable = Column(Boolean, default=False)
    fixed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    addon = relationship("Addon", back_populates="reports")


class FileRecord(Base):
    __tablename__ = "files"
    id = Column(Integer, primary_key=True, index=True)
    addon_id = Column(Integer, ForeignKey("addons.id"))
    file_path = Column(String)
    file_type = Column(String)
    file_size = Column(Integer, default=0)
    error_count = Column(Integer, default=0)
    warning_count = Column(Integer, default=0)
    addon = relationship("Addon", back_populates="files")
