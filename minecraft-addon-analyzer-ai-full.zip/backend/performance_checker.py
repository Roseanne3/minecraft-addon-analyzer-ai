import os
import json
from json_validator import load_json_safe

MAX_JSON_SIZE_KB = 100
MAX_NESTING_DEPTH = 10
MAX_ENTITY_COMPONENTS = 40
MAX_ANIMATIONS = 20


def _measure_nesting(obj, depth=0) -> int:
    if isinstance(obj, dict):
        if not obj:
            return depth
        return max(_measure_nesting(v, depth + 1) for v in obj.values())
    elif isinstance(obj, list):
        if not obj:
            return depth
        return max(_measure_nesting(v, depth + 1) for v in obj)
    return depth


def check_performance(addon_path: str, file_list: list) -> list:
    issues = []
    animation_count = 0

    for f in file_list:
        full = f["full_path"]
        rel = f["relative_path"]
        size_kb = f["size"] / 1024

        # Large JSON files
        if f["extension"] == ".json" and size_kb > MAX_JSON_SIZE_KB:
            issues.append({
                "severity": "warning",
                "message": f"Large JSON file ({size_kb:.1f} KB): {rel}",
                "file_path": rel,
                "fix_suggestion": "Split into smaller files or remove unused data",
                "auto_fixable": False,
            })

        # Deep nesting
        if f["extension"] == ".json":
            data = load_json_safe(full)
            if data:
                depth = _measure_nesting(data)
                if depth > MAX_NESTING_DEPTH:
                    issues.append({
                        "severity": "warning",
                        "message": f"Deep JSON nesting ({depth} levels): {rel}",
                        "file_path": rel,
                        "fix_suggestion": "Flatten structure to reduce nesting depth",
                        "auto_fixable": False,
                    })

                # Too many entity components
                if "minecraft:entity" in data:
                    components = data["minecraft:entity"].get("components", {})
                    if len(components) > MAX_ENTITY_COMPONENTS:
                        issues.append({
                            "severity": "warning",
                            "message": f"Entity has {len(components)} components (>{MAX_ENTITY_COMPONENTS}): {rel}",
                            "file_path": rel,
                            "fix_suggestion": "Move some components to component groups for conditional loading",
                            "auto_fixable": False,
                        })

                # Count animations
                if "animations" in data:
                    animation_count += len(data.get("animations", {}))

        # Large textures
        if f["extension"] in [".png", ".jpg", ".tga"]:
            size_mb = f["size"] / (1024 * 1024)
            if size_mb > 4:
                issues.append({
                    "severity": "error",
                    "message": f"Very large texture ({size_mb:.1f} MB): {rel}",
                    "file_path": rel,
                    "fix_suggestion": "Resize texture; Bedrock recommends max 256x256 for entities",
                    "auto_fixable": False,
                })
            elif size_mb > 1:
                issues.append({
                    "severity": "warning",
                    "message": f"Large texture ({size_mb:.1f} MB): {rel}",
                    "file_path": rel,
                    "fix_suggestion": "Optimize to reduce loading time",
                    "auto_fixable": False,
                })

    if animation_count > MAX_ANIMATIONS:
        issues.append({
            "severity": "warning",
            "message": f"Addon has {animation_count} total animations — may impact performance",
            "file_path": "animations/",
            "fix_suggestion": "Reduce animation count or combine animations where possible",
            "auto_fixable": False,
        })

    return issues
