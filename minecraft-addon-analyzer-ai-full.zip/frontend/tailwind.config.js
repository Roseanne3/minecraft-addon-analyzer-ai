/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        mc: {
          green: "#5C8A3C",
          dirt: "#8B6340",
          stone: "#8E8E8E",
          dark: "#0D0D0D",
          darker: "#080808",
          panel: "#141414",
          border: "#2A2A2A",
          accent: "#00FF7F",
          gold: "#FFD700",
          red: "#FF4444",
          blue: "#4FC3F7",
        },
      },
      fontFamily: {
        mono: ["'JetBrains Mono'", "monospace"],
        display: ["'Orbitron'", "monospace"],
      },
    },
  },
  plugins: [],
};
