import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

const COLORS = {
  error: "#ff4455",
  warning: "#ffd700",
  info: "#4fc3f7",
  manifest: "#a78bfa",
  json: "#fb923c",
  behavior: "#34d399",
  resource: "#60a5fa",
  dependency: "#f472b6",
  performance: "#facc15",
  ai: "#c084fc",
  structure: "#94a3b8",
};

export function ErrorDistributionChart({ stats }) {
  const ref = useRef(null);
  const chart = useRef(null);

  useEffect(() => {
    if (!stats || !ref.current) return;
    if (chart.current) chart.current.destroy();

    const byType = stats.by_type || {};
    const labels = Object.keys(byType);
    const data = Object.values(byType);
    const colors = labels.map(l => COLORS[l] || "#64748b");

    chart.current = new Chart(ref.current, {
      type: "doughnut",
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: colors.map(c => c + "aa"),
          borderColor: colors,
          borderWidth: 1.5,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "right",
            labels: {
              color: "#94a3b8",
              font: { family: "'JetBrains Mono'", size: 11 },
              boxWidth: 10,
              padding: 8,
            },
          },
          tooltip: {
            backgroundColor: "#12121e",
            borderColor: "#1e1e3a",
            borderWidth: 1,
            titleColor: "#e2e8f0",
            bodyColor: "#94a3b8",
            titleFont: { family: "'Orbitron'", size: 10 },
            bodyFont: { family: "'JetBrains Mono'", size: 11 },
          },
        },
        cutout: "65%",
      },
    });
    return () => chart.current?.destroy();
  }, [stats]);

  return (
    <div style={{ height: "200px", position: "relative" }}>
      <canvas ref={ref} />
    </div>
  );
}

export function FileTypesChart({ fileTypes }) {
  const ref = useRef(null);
  const chart = useRef(null);

  useEffect(() => {
    if (!fileTypes || !ref.current) return;
    if (chart.current) chart.current.destroy();

    const labels = Object.keys(fileTypes);
    const data = Object.values(fileTypes);

    chart.current = new Chart(ref.current, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: labels.map((_, i) => `hsl(${i * 40}, 60%, 50%)aa`),
          borderColor: labels.map((_, i) => `hsl(${i * 40}, 60%, 60%)`),
          borderWidth: 1,
          borderRadius: 2,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#12121e",
            borderColor: "#1e1e3a",
            borderWidth: 1,
            titleColor: "#e2e8f0",
            bodyColor: "#94a3b8",
            titleFont: { family: "'Orbitron'", size: 10 },
            bodyFont: { family: "'JetBrains Mono'", size: 11 },
          },
        },
        scales: {
          x: {
            ticks: { color: "#64748b", font: { family: "'JetBrains Mono'", size: 10 } },
            grid: { color: "#1e1e3a" },
          },
          y: {
            ticks: { color: "#64748b", font: { family: "'JetBrains Mono'", size: 10 } },
            grid: { color: "#1e1e3a" },
            beginAtZero: true,
          },
        },
      },
    });
    return () => chart.current?.destroy();
  }, [fileTypes]);

  return (
    <div style={{ height: "200px", position: "relative" }}>
      <canvas ref={ref} />
    </div>
  );
}

export function SeverityChart({ stats }) {
  const ref = useRef(null);
  const chart = useRef(null);

  useEffect(() => {
    if (!stats || !ref.current) return;
    if (chart.current) chart.current.destroy();

    chart.current = new Chart(ref.current, {
      type: "bar",
      data: {
        labels: ["Errors", "Warnings", "Info"],
        datasets: [{
          data: [stats.errors || 0, stats.warnings || 0, stats.info || 0],
          backgroundColor: ["#ff445544", "#ffd70044", "#4fc3f744"],
          borderColor: ["#ff4455", "#ffd700", "#4fc3f7"],
          borderWidth: 1.5,
          borderRadius: 2,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: "#12121e",
            borderColor: "#1e1e3a",
            borderWidth: 1,
            titleColor: "#e2e8f0",
            bodyColor: "#94a3b8",
          },
        },
        scales: {
          x: {
            ticks: { color: "#94a3b8", font: { family: "'JetBrains Mono'", size: 11 } },
            grid: { color: "#1e1e3a" },
          },
          y: {
            ticks: { color: "#64748b", font: { family: "'JetBrains Mono'", size: 10 } },
            grid: { color: "#1e1e3a" },
            beginAtZero: true,
          },
        },
      },
    });
    return () => chart.current?.destroy();
  }, [stats]);

  return (
    <div style={{ height: "180px", position: "relative" }}>
      <canvas ref={ref} />
    </div>
  );
}
