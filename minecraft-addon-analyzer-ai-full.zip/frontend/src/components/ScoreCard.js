export default function ScoreCard({ score = 0 }) {
  const getColor = (s) => {
    if (s >= 80) return "#00ff7f";
    if (s >= 60) return "#ffd700";
    if (s >= 40) return "#ff9900";
    return "#ff4455";
  };
  const getLabel = (s) => {
    if (s >= 90) return "EXCELLENT";
    if (s >= 80) return "GOOD";
    if (s >= 60) return "FAIR";
    if (s >= 40) return "POOR";
    return "CRITICAL";
  };

  const color = getColor(score);
  const radius = 54;
  const circ = 2 * Math.PI * radius;
  const dash = (score / 100) * circ;

  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      padding: "1.5rem", background: "var(--bg-card)",
      border: "1px solid var(--border)", position: "relative", overflow: "hidden",
    }}>
      <div className="section-label" style={{ marginBottom: "1rem" }}>Addon Score</div>

      <div style={{ position: "relative", width: "140px", height: "140px" }}>
        <svg width="140" height="140" style={{ transform: "rotate(-90deg)" }}>
          {/* Track */}
          <circle cx="70" cy="70" r={radius} fill="none" stroke="#1e1e3a" strokeWidth="8" />
          {/* Score arc */}
          <circle
            cx="70" cy="70" r={radius}
            fill="none"
            stroke={color}
            strokeWidth="8"
            strokeDasharray={`${dash} ${circ - dash}`}
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${color})`, transition: "stroke-dasharray 0.8s ease" }}
          />
        </svg>
        <div style={{
          position: "absolute", inset: 0,
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
        }}>
          <span style={{
            fontFamily: "var(--font-display)", fontSize: "2rem", fontWeight: 900,
            color, lineHeight: 1,
            textShadow: `0 0 20px ${color}`,
          }}>
            {Math.round(score)}
          </span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.65rem", color: "var(--text-muted)" }}>
            / 100
          </span>
        </div>
      </div>

      <div style={{
        marginTop: "0.75rem",
        fontFamily: "var(--font-display)",
        fontSize: "0.7rem",
        letterSpacing: "0.2em",
        color,
        textShadow: `0 0 12px ${color}`,
      }}>
        {getLabel(score)}
      </div>
    </div>
  );
}
