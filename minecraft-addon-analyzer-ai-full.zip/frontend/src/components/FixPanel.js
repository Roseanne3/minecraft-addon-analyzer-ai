import { useState } from "react";
import axios from "axios";

const API = "http://localhost:8000";

export default function FixPanel({ addonId, stats }) {
  const [fixing, setFixing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const autoFix = async () => {
    setFixing(true);
    setError(null);
    setResult(null);
    try {
      const res = await axios.post(`${API}/addon/${addonId}/fix`);
      setResult(res.data);
    } catch (e) {
      setError(e.response?.data?.detail || "Fix failed");
    } finally {
      setFixing(false);
    }
  };

  const autoFixable = stats?.errors || 0;

  return (
    <div className="mc-card" style={{ padding: "1.25rem" }}>
      <div className="section-label" style={{ marginBottom: "1rem" }}>Auto Fix Engine</div>

      <div style={{ marginBottom: "1rem" }}>
        <p style={{ fontSize: "0.75rem", color: "var(--text-muted)", lineHeight: 1.6 }}>
          Automatically repair common addon issues: invalid JSON, broken manifests, missing UUIDs, and structural problems.
        </p>
      </div>

      {/* Stats preview */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.5rem", marginBottom: "1rem" }}>
        {[
          { label: "Auto-Fixable", val: autoFixable, color: "var(--accent)" },
          { label: "Total Issues", val: stats?.total_issues || 0, color: "var(--text-muted)" },
        ].map(({ label, val, color }) => (
          <div key={label} style={{
            background: "var(--bg-dark)", border: "1px solid var(--border)",
            padding: "0.6rem", textAlign: "center",
          }}>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "1.25rem", color }}>{val}</div>
            <div style={{ fontSize: "0.6rem", color: "var(--text-muted)", marginTop: "0.2rem" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Fix button */}
      <button
        className="mc-btn mc-btn-primary"
        onClick={autoFix}
        disabled={fixing}
        style={{ width: "100%", padding: "0.75rem", fontSize: "0.75rem" }}
      >
        {fixing ? (
          <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "0.5rem" }}>
            <span className="spinner" style={{ width: "14px", height: "14px" }} /> FIXING...
          </span>
        ) : "⚡ AUTO FIX ADDON"}
      </button>

      {error && (
        <div style={{
          marginTop: "0.75rem", padding: "0.75rem",
          background: "#ff445511", border: "1px solid #ff445533",
          fontSize: "0.72rem", color: "var(--red)",
        }}>
          ✕ {error}
        </div>
      )}

      {result && (
        <div style={{ marginTop: "0.75rem" }}>
          <div style={{
            padding: "0.75rem",
            background: "#00ff7f11", border: "1px solid #00ff7f33",
            marginBottom: "0.75rem",
          }}>
            <div style={{ fontSize: "0.72rem", color: "var(--accent)", fontWeight: 600, marginBottom: "0.4rem" }}>
              ✓ Fixed {result.fixes_applied?.length || 0} issues
            </div>
            <ul style={{ paddingLeft: "1rem", margin: 0 }}>
              {result.fixes_applied?.map((fix, i) => (
                <li key={i} style={{ fontSize: "0.68rem", color: "var(--text-muted)", marginBottom: "0.2rem" }}>
                  {fix}
                </li>
              ))}
            </ul>
          </div>

          {/* Download button */}
          <a
            href={`${API}/addon/${addonId}/download-fixed`}
            download
            className="mc-btn"
            style={{
              display: "block", textAlign: "center", textDecoration: "none",
              padding: "0.6rem", fontSize: "0.72rem", width: "100%",
            }}
          >
            ⬇ DOWNLOAD FIXED ADDON
          </a>
        </div>
      )}
    </div>
  );
}
