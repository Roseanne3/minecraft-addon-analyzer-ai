import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:8000";

export default function Navbar() {
  const [recentAddons, setRecentAddons] = useState([]);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`${API}/addons`).then(r => setRecentAddons(r.data)).catch(() => {});
  }, []);

  return (
    <nav style={{
      position: "fixed", top: 0, left: 0, right: 0, height: "60px",
      background: "rgba(8,8,16,0.95)",
      borderBottom: "1px solid #1e1e3a",
      backdropFilter: "blur(12px)",
      display: "flex", alignItems: "center", justifyContent: "space-between",
      padding: "0 1.5rem", zIndex: 1000,
    }}>
      {/* Logo */}
      <Link to="/" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: "0.75rem" }}>
        <div style={{
          width: "32px", height: "32px",
          background: "linear-gradient(135deg, #00ff7f, #00cc60)",
          clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "14px",
        }}>⛏</div>
        <div>
          <div style={{ fontFamily: "var(--font-display)", fontSize: "0.75rem", color: "var(--accent)", letterSpacing: "0.1em" }}>
            ADDON ANALYZER
          </div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "0.6rem", color: "var(--text-muted)", letterSpacing: "0.05em" }}>
            AI · BEDROCK EDITION
          </div>
        </div>
      </Link>

      {/* Nav links */}
      <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
        <Link to="/" className="mc-btn" style={{ padding: "0.4rem 1rem", fontSize: "0.65rem" }}>Upload</Link>

        {/* Recent addons dropdown */}
        <div style={{ position: "relative" }}>
          <button
            className="mc-btn"
            style={{ padding: "0.4rem 1rem", fontSize: "0.65rem" }}
            onClick={() => setOpen(!open)}
          >
            Recent ▾
          </button>
          {open && (
            <div style={{
              position: "absolute", top: "calc(100% + 8px)", right: 0,
              background: "var(--bg-card)", border: "1px solid var(--border)",
              minWidth: "260px", zIndex: 200,
            }}>
              {recentAddons.length === 0 ? (
                <div style={{ padding: "1rem", color: "var(--text-muted)", fontSize: "0.75rem" }}>
                  No recent addons
                </div>
              ) : recentAddons.map(a => (
                <button
                  key={a.id}
                  onClick={() => { navigate(`/dashboard/${a.id}`); setOpen(false); }}
                  style={{
                    display: "block", width: "100%", padding: "0.6rem 1rem",
                    background: "none", border: "none", cursor: "pointer",
                    textAlign: "left", borderBottom: "1px solid var(--border)",
                    color: "var(--text)", fontFamily: "var(--font-mono)", fontSize: "0.72rem",
                  }}
                  onMouseEnter={e => e.currentTarget.style.background = "#1e1e3a"}
                  onMouseLeave={e => e.currentTarget.style.background = "none"}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: "160px" }}>
                      {a.filename}
                    </span>
                    <span style={{
                      fontSize: "0.65rem",
                      color: a.score >= 80 ? "var(--accent)" : a.score >= 50 ? "var(--gold)" : "var(--red)"
                    }}>
                      {a.score?.toFixed(0)}%
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        <a
          href="https://learn.microsoft.com/en-us/minecraft/creator/"
          target="_blank"
          rel="noopener noreferrer"
          className="mc-btn"
          style={{ padding: "0.4rem 1rem", fontSize: "0.65rem" }}
        >
          MC Docs ↗
        </a>
      </div>
    </nav>
  );
}
