import { useState } from "react";

const TYPE_ICONS = {
  manifest: "📋", entity: "🧟", item: "⚔️", texture: "🖼️",
  animation: "🎞️", model: "🗿", script: "📜", function: "⚙️",
  sound: "🔊", loot_table: "🎲", json: "📄", biome: "🌍",
  particle: "✨", archive: "📦", other: "📁",
};

function buildTree(files) {
  const root = {};
  files.forEach(f => {
    const parts = f.path.replace(/\\/g, "/").split("/");
    let node = root;
    parts.forEach((part, i) => {
      if (!node[part]) {
        node[part] = { __files: [], __children: {} };
      }
      if (i === parts.length - 1) {
        node[part].__file = f;
      } else {
        node = node[part].__children;
      }
    });
  });
  return root;
}

function TreeNode({ name, node, depth = 0, onSelect, selected }) {
  const isFile = !!node.__file;
  const children = node.__children || {};
  const hasChildren = Object.keys(children).length > 0;
  const [open, setOpen] = useState(depth < 2);

  const file = node.__file;
  const icon = file ? (TYPE_ICONS[file.type] || "📄") : "📂";
  const isSelected = file && selected === file.path;

  return (
    <div>
      <div
        onClick={() => {
          if (!isFile) setOpen(!open);
          else onSelect(file);
        }}
        style={{
          display: "flex", alignItems: "center", gap: "0.4rem",
          padding: `0.2rem 0.5rem 0.2rem ${depth * 16 + 8}px`,
          cursor: "pointer",
          background: isSelected ? "#00ff7f15" : "none",
          borderLeft: isSelected ? "2px solid var(--accent)" : "2px solid transparent",
          fontSize: "0.72rem",
          color: isFile ? "var(--text)" : "var(--text-muted)",
          transition: "background 0.15s",
        }}
        onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = "#ffffff08"; }}
        onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = "none"; }}
      >
        <span style={{ flexShrink: 0, fontSize: "0.8rem" }}>
          {!isFile ? (open ? "▾" : "▸") : icon}
        </span>
        <span style={{
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          color: isFile ? "var(--text)" : "#a0aec0",
        }}>
          {name}
        </span>
        {isFile && (file.errors > 0 || file.warnings > 0) && (
          <span style={{ marginLeft: "auto", display: "flex", gap: "0.25rem", flexShrink: 0 }}>
            {file.errors > 0 && (
              <span className="mc-badge badge-error">{file.errors}</span>
            )}
            {file.warnings > 0 && (
              <span className="mc-badge badge-warning">{file.warnings}</span>
            )}
          </span>
        )}
        {isFile && (
          <span style={{ marginLeft: "auto", color: "var(--text-muted)", fontSize: "0.6rem", flexShrink: 0 }}>
            {(file.size / 1024).toFixed(1)}K
          </span>
        )}
      </div>

      {!isFile && open && Object.entries(children).map(([childName, childNode]) => (
        <TreeNode
          key={childName}
          name={childName}
          node={childNode}
          depth={depth + 1}
          onSelect={onSelect}
          selected={selected}
        />
      ))}
    </div>
  );
}

export default function FileTree({ files = [], onSelect, selected }) {
  const tree = buildTree(files);
  const [search, setSearch] = useState("");

  const filtered = search
    ? files.filter(f => f.path.toLowerCase().includes(search.toLowerCase()))
    : null;

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "0.5rem" }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Filter files..."
          style={{
            width: "100%",
            background: "var(--bg-dark)",
            border: "1px solid var(--border)",
            color: "var(--text)",
            fontFamily: "var(--font-mono)",
            fontSize: "0.72rem",
            padding: "0.4rem 0.6rem",
            outline: "none",
          }}
        />
      </div>
      <div style={{ overflow: "auto", flex: 1 }}>
        {search ? (
          filtered.map(f => (
            <div
              key={f.path}
              onClick={() => onSelect(f)}
              style={{
                padding: "0.3rem 0.75rem",
                fontSize: "0.72rem",
                cursor: "pointer",
                color: selected === f.path ? "var(--accent)" : "var(--text)",
                background: selected === f.path ? "#00ff7f10" : "none",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={e => e.currentTarget.style.background = "#ffffff08"}
              onMouseLeave={e => e.currentTarget.style.background = selected === f.path ? "#00ff7f10" : "none"}
            >
              {TYPE_ICONS[f.type] || "📄"} {f.path}
            </div>
          ))
        ) : (
          Object.entries(tree).map(([name, node]) => (
            <TreeNode key={name} name={name} node={node} onSelect={onSelect} selected={selected} />
          ))
        )}
        {files.length === 0 && (
          <div style={{ padding: "1rem", color: "var(--text-muted)", fontSize: "0.75rem", textAlign: "center" }}>
            No files
          </div>
        )}
      </div>
    </div>
  );
}
