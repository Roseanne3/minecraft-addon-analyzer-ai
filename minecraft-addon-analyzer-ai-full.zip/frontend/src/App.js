import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import UploadPage from "./pages/UploadPage";
import Dashboard from "./pages/Dashboard";
import FileViewer from "./pages/FileViewer";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <div style={{ paddingTop: "60px" }}>
        <Routes>
          <Route path="/" element={<UploadPage />} />
          <Route path="/dashboard/:addonId" element={<Dashboard />} />
          <Route path="/viewer/:addonId" element={<FileViewer />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
