import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import FileTree from "../components/FileTree";

const API = "http://localhost:8000";

const TYPE_COLORS = {
  manifest: "#a78bfa", entity: "#34d399", item: "#60a5fa",
  texture: "#fb923c", animation: "#f472b6", model: "#facc15",
  script: "#4fc3f7", function: "#c084fc", sound: "#94a3b8",
  loot_table: "#fbbf24", json: "#e2e8f0", other: "#64748b",
};

function FileDetailPanel({ addonId, file }) {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!file) return;
    setLoading(true);
    axios.get(`${API}/addon/${addonId}/file-reports`, { params: { file_path: file.path } })
      .then(r => { setReports(r.data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [file, addonId]);

  if (!file) return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", height: "100%", color: "var(--text-muted)",
      gap: "1rem",
    }}>
      <div style={{ fontSize: "3rem" }}>📂</div>
      <div style={{ fontFamily: "var(--font-display)", fontSize: "0.7rem", letterSpacing: "0.1em" }}>
        SELECT A FILE
      </div>
      <div style={{ fontSize: "0.7rem" }}>Click any file in the tree to view analysis</div>
    </div>
  );

  const errors = reports.filter(r => r.severity === "error");
  const warnings = reports.filter(r => r.severity === "warning");
  const infos = reports.filter(r => r.severity === "info");
  const typeColor = TYPE_COLORS[file.type] || "#64748b";

  return (
    <div style={{ height: "100%", overflow: "auto", padding: "1.25rem" }}>
      {/* File header */}
      <div style={{
        background: "var(--bg-dark)", border: "1px solid var(--border)",
        padding: "1rem", marginBottom: "1rem",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem", marginBottom: "0.5rem" }}>
          <span style={{
            background: typeColor + "22", border: `1px solid ${typeColor}44`,
            color: typeColor, fontSize: "0.65rem", padding: "0.2rem 0.6rem",
            fontFamily: "var(--font-mono)",
          }}>
            {file.type.toUpperCase()}
          </span>
          <div style={{ display: "flex", gap: "0.5rem" }}>
            {errors.length > 0 && <span className="mc-badge badge-error">{errors.length} errors</span>}
            {warnings.length > 0 && <span className="mc-badge badge-warning">{warnings.length} warnings</span>}
            {infos.length > 0 && <span className="mc-badge badge-info">{infos.length} info</span>}
            {reports.length === 0 && (
              <span style={{ fontSize: "0.65rem", color: "var(--accent)" }}>✓ No issues</span>
            )}
          </div>
        </div>
        <div style={{
          fontFamily: "var(--font-mono)", fontSize: "0.78rem",
          color: "var(--text)", wordBreak: "break-all",
        }}>
          {file.path}
        </div>
        <div style={{ fontSize: "0.65rem", color: "var(--text-muted)", marginTop: "0.3rem" }}>
          Size: {(file.size / 1024).toFixed(1)} KB
        </div>
      </div>

      {loading && (
        <div style={{ display: "flex", justifyContent: "center", padding: "2rem" }}>
          <div className="spinner" />
        </div>
      )}

      {!loading && reports.length === 0 && (
        <div style={{
          textAlign: "center", padding: "2rem",
          color: "var(--accent)", fontFamily: "var(--font-display)", fontSize: "0.72rem",
        }}>
          ✓ THIS FILE HAS NO ISSUES
        </div>
      )}

      {/* Reports grouped by type */}
      {!loading && [
        { label: "ERRORS", items: errors, badge: "badge-error" },
        { label: "WARNINGS", items: warnings, badge: "badge-warning" },
        { label: "INFO & AI", items: infos, badge: "badge-info" },
      ].map(({ label, items, badge }) => items.length > 0 && (
        <div key={label} style={{ marginBottom: "1rem" }}>
          <div className="section-label" style={{ marginBottom: "0.5rem" }}>{label}</div>
          {items.map((r, i) => (
            <div key={i} style={{
              background: "var(--bg-dark)", border: "1px solid var(--border)",
              padding: "0.75rem", marginBottom: "0.4rem",
            }}>
              <div style={{ display: "flex", gap: "0.5rem", alignItems: "flex-start", marginBottom: "0.4rem" }}>
                <span className={`mc-badge ${badge}`} style={{ flexShrink: 0 }}>
                  {r.report_type?.toUpperCase() || r.severity?.toUpperCase()}
                </span>
                {r.auto_fixable && (
                  <span style={{
                    fontSize: "0.6rem", color: "var(--accent)",
                    border: "1px solid var(--accent-dim)", padding: "0.1rem 0.4rem",
                  }}>
                    AUTO-FIX
                  </span>
                )}
              </div>
              <div style={{ fontSize: "0.75rem", color: "var(--text)", lineHeight: 1.5 }}>
                {r.message}
              </div>
              {r.fix_suggestion && (
                <div style={{
                  marginTop: "0.5rem", padding: "0.5rem",
                  background: "#00ff7f08", border: "1px solid #00ff7f22",
                  fontSize: "0.7rem", color: "var(--text-muted)", lineHeight: 1.5,
                }}>
                  <span style={{ color: "var(--accent)" }}>💡 </span>
                  {r.fix_suggestion}
                </div>
              )}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export default function FileViewer() {
  const { addonId } = useParams();
  const [addonData, setAddonData] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`${API}/addon/${addonId}`)
      .then(r => { setAddonData(r.data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [addonId]);

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "60vh", gap: "1rem" }}>
      <div className="spinner" style={{ width: "32px", height: "32px" }} />
    </div>
  );

  if (!addonData) return (
    <div style={{ textAlign: "center", padding: "4rem", color: "var(--text-muted)" }}>
      Addon not found.
    </div>
  );

  return (
    <div style={{ height: "calc(100vh - 60px)", display: "flex", flexDirection: "column" }}>
      {/* Toolbar */}
      <div style={{
        display: "flex", alignItems: "center", gap: "1rem",
        padding: "0.75rem 1.5rem",
        background: "var(--bg-card)", borderBottom: "1px solid var(--border)",
        flexShrink: 0,
      }}>
        <Link to={`/dashboard/${addonId}`} className="mc-btn" style={{ fontSize: "0.65rem", padding: "0.35rem 0.8rem" }}>
          ← Dashboard
        </Link>
        <div style={{ flex: 1 }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: "0.7rem", color: "var(--accent)", letterSpacing: "0.1em" }}>
            FILE EXPLORER
          </span>
          <span style={{ fontFamily: "var(--font-mono)", fontSize: "0.65rem", color: "var(--text-muted)", marginLeft: "0.75rem" }}>
            {addonData.filename} · {addonData.files?.length || 0} files
          </span>
        </div>
        <div style={{ display: "flex", gap: "0.5rem" }}>
          <span className="mc-badge badge-error">{addonData.stats?.errors || 0} errors</span>
          <span className="mc-badge badge-warning">{addonData.stats?.warnings || 0} warnings</span>
        </div>
      </div>

      {/* Main split view */}
      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", flex: 1, overflow: "hidden" }}>
        {/* File tree */}
        <div style={{
          borderRight: "1px solid var(--border)",
          background: "var(--bg-card)",
          overflow: "hidden", display: "flex", flexDirection: "column",
        }}>
          <div style={{
            padding: "0.6rem 0.75rem",
            borderBottom: "1px solid var(--border)",
          }}>
            <div className="section-label">ADDON FILES</div>
          </div>
          <FileTree
            files={addonData.files || []}
            onSelect={setSelectedFile}
            selected={selectedFile?.path}
          />
        </div>

        {/* Detail panel */}
        <div style={{ background: "var(--bg-panel)", overflow: "hidden" }}>
          <FileDetailPanel addonId={addonId} file={selectedFile} />
        </div>
      </div>
    </div>
  );
}
