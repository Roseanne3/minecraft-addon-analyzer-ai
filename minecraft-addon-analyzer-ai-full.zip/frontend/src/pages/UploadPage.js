import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const API = "http://localhost:8000";
const ACCEPTED = [".zip", ".mcaddon", ".mcpack"];

export default function UploadPage() {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleFile = (f) => {
    setError(null);
    const ext = "." + f.name.split(".").pop().toLowerCase();
    if (!ACCEPTED.includes(ext)) {
      setError(`Invalid file type: ${ext}. Accepted: ${ACCEPTED.join(", ")}`);
      return;
    }
    setFile(f);
  };

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, []);

  const onDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);

  const upload = async () => {
    if (!file) return;
    setUploading(true);
    setProgress(0);
    setError(null);

    const fd = new FormData();
    fd.append("file", file);

    try {
      const res = await axios.post(`${API}/upload-addon`, fd, {
        headers: { "Content-Type": "multipart/form-data" },
        onUploadProgress: (e) => {
          setProgress(Math.round((e.loaded * 100) / e.total));
        },
      });
      navigate(`/dashboard/${res.data.addon_id}`);
    } catch (e) {
      setError(e.response?.data?.detail || "Upload failed. Is the backend running?");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div style={{
      minHeight: "calc(100vh - 60px)",
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      padding: "2rem",
    }}>
      {/* Hero */}
      <div style={{ textAlign: "center", marginBottom: "3rem" }} className="fade-up">
        <div style={{
          fontFamily: "var(--font-display)", fontSize: "clamp(1.5rem, 4vw, 2.5rem)",
          fontWeight: 900, letterSpacing: "0.08em",
          background: "linear-gradient(135deg, #00ff7f, #00cc60, #4fc3f7)",
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          marginBottom: "1rem", lineHeight: 1.2,
        }}>
          MINECRAFT ADDON<br />ANALYZER AI
        </div>
        <p style={{
          color: "var(--text-muted)", fontFamily: "var(--font-mono)", fontSize: "0.85rem",
          maxWidth: "480px", lineHeight: 1.7,
        }}>
          Upload your addon to detect errors, broken assets, and performance problems.
          Auto-fix common issues instantly.
        </p>
      </div>

      {/* Upload box */}
      <div style={{ width: "100%", maxWidth: "560px" }} className="fade-up">
        <div
          onDrop={onDrop}
          onDragOver={onDragOver}
          onDragLeave={onDragLeave}
          onClick={() => !uploading && document.getElementById("file-input").click()}
          style={{
            border: `2px dashed ${dragging ? "var(--accent)" : file ? "#00ff7f66" : "var(--border)"}`,
            background: dragging ? "#00ff7f08" : file ? "#00ff7f05" : "var(--bg-card)",
            padding: "3rem 2rem",
            textAlign: "center",
            cursor: uploading ? "default" : "pointer",
            transition: "all 0.2s",
            marginBottom: "1rem",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {dragging && (
            <div style={{
              position: "absolute", inset: 0,
              background: "linear-gradient(135deg, #00ff7f08, transparent)",
              pointerEvents: "none",
            }} />
          )}

          <input
            id="file-input"
            type="file"
            accept=".zip,.mcaddon,.mcpack"
            style={{ display: "none" }}
            onChange={e => e.target.files[0] && handleFile(e.target.files[0])}
          />

          {!file ? (
            <>
              <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>📦</div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "0.85rem", color: "var(--text)", marginBottom: "0.5rem" }}>
                DROP ADDON HERE
              </div>
              <div style={{ fontSize: "0.72rem", color: "var(--text-muted)" }}>
                or click to browse
              </div>
              <div style={{
                marginTop: "1.5rem", display: "flex", gap: "0.5rem", justifyContent: "center", flexWrap: "wrap",
              }}>
                {ACCEPTED.map(ext => (
                  <span key={ext} style={{
                    background: "#00ff7f15", border: "1px solid #00ff7f33",
                    color: "var(--accent)", fontSize: "0.65rem", padding: "0.2rem 0.6rem",
                    fontFamily: "var(--font-mono)",
                  }}>
                    {ext}
                  </span>
                ))}
              </div>
            </>
          ) : (
            <>
              <div style={{ fontSize: "3rem", marginBottom: "0.75rem" }}>✅</div>
              <div style={{ fontFamily: "var(--font-display)", fontSize: "0.8rem", color: "var(--accent)", marginBottom: "0.4rem" }}>
                {file.name}
              </div>
              <div style={{ fontSize: "0.7rem", color: "var(--text-muted)" }}>
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </div>
              {!uploading && (
                <button
                  onClick={e => { e.stopPropagation(); setFile(null); }}
                  style={{
                    marginTop: "0.75rem", background: "none", border: "none",
                    color: "var(--text-muted)", cursor: "pointer", fontSize: "0.72rem",
                  }}
                >
                  ✕ Remove
                </button>
              )}
            </>
          )}
        </div>

        {/* Progress bar */}
        {uploading && (
          <div style={{ marginBottom: "1rem" }}>
            <div style={{ height: "3px", background: "var(--border)", position: "relative", overflow: "hidden" }}>
              <div style={{
                position: "absolute", top: 0, left: 0, bottom: 0,
                width: `${progress}%`,
                background: "var(--accent)",
                boxShadow: "0 0 8px var(--accent)",
                transition: "width 0.2s",
              }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: "0.3rem" }}>
              <span style={{ fontSize: "0.65rem", color: "var(--text-muted)" }}>
                {progress < 100 ? "Uploading..." : "Analyzing addon..."}
              </span>
              <span style={{ fontSize: "0.65rem", color: "var(--accent)" }}>{progress}%</span>
            </div>
          </div>
        )}

        {error && (
          <div style={{
            padding: "0.75rem 1rem", marginBottom: "1rem",
            background: "#ff445511", border: "1px solid #ff445544",
            fontSize: "0.75rem", color: "var(--red)",
            display: "flex", alignItems: "center", gap: "0.5rem",
          }}>
            <span>✕</span> {error}
          </div>
        )}

        <button
          className="mc-btn mc-btn-primary"
          onClick={upload}
          disabled={!file || uploading}
          style={{
            width: "100%", padding: "0.9rem",
            fontSize: "0.85rem", letterSpacing: "0.15em",
            opacity: !file || uploading ? 0.5 : 1,
            cursor: !file || uploading ? "not-allowed" : "pointer",
          }}
        >
          {uploading ? "ANALYZING..." : "ANALYZE ADDON"}
        </button>

        {/* Feature pills */}
        <div style={{
          display: "flex", gap: "0.5rem", flexWrap: "wrap",
          justifyContent: "center", marginTop: "2rem",
        }}>
          {[
            "Manifest Check", "JSON Validation", "Behavior Pack",
            "Resource Pack", "Dependencies", "Performance", "AI Analysis", "Auto Fix"
          ].map(f => (
            <span key={f} style={{
              background: "#1e1e3a", border: "1px solid var(--border)",
              color: "var(--text-muted)", fontSize: "0.62rem",
              padding: "0.2rem 0.6rem", fontFamily: "var(--font-mono)",
            }}>{f}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
